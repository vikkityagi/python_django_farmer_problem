"""farmer URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from addfarmer import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [


    path('admin/', admin.site.urls),
    path('',views.welcome),
    path('load_forms1',views.load_forms1),
    path('add',views.add),
    path('success',views.success),
    path('success1',views.success1),
    #path('reason',views.reason),

    path('deletefarmer',views.deletefarmer),
    path('deletesearch',views.deletesearch),
    path('delete/<int:id>',views.delete),

    path('adhar',views.adhar),
    path('searchupdate',views.searchupdate),
    path('edit/<int:id>',views.edit),
    path('update/<int:id>',views.update),

    path('show2', views.show2),
    path('deletereason/<int:id>',views.deletereason),
    path('show',views.show),

    path('index',views.index),
    path('login', views.login),

    path('search2',views.search2),

    path('problem', views.problem),
    path('addproblem',views.addproblem),

    path('showfarmerproblem', views.showfarmerproblem),
    path('showfarmerproblem1', views.showfarmerproblem1),
    path('deletefarmerproblem/<int:id>', views.deletefarmerproblem),
    #image
    path('showimage/<int:id>',views.showimage),

    #about
    path('abouthome',views.abouthome),

    #problemform
   # path('problemform',views.problemform),
    path('problemform/<int:id>',views.problemform),
    path('answer',views.answer),
    path('book',views.book),

    #19/09/2020
    path('savebooking',views.savebooking),
    path('successbooking',views.successbooking),

]
if settings.DEBUG:
		urlpatterns += static(settings.MEDIA_URL,
							document_root=settings.MEDIA_ROOT)
