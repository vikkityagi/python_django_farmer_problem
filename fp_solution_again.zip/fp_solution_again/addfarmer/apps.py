from django.apps import AppConfig


class AddfarmerConfig(AppConfig):
    name = 'addfarmer'
