from django.shortcuts import render, redirect
from django.http import HttpResponseRedirect
from .models import Add_Farmer1
from .forms1 import AddFarmerForm1
from .models import Reason1
from .forms2 import ReasonForm1
from .models import Problem1
from .forms3 import ProblemForm1
#16/09/2020
from .models import Bookfarmer
from .forms5 import BookFarmerform
#from .models import Image
#from .forms4 import ImageForm



# Create your views here.
def welcome(request):
    return render(request,'welcome.html')

#add farmer
def load_forms1(request):
    if request.method == 'POST':
        form1 = AddFarmerForm1(request.POST, request.FILES)

        if form1.is_valid():
            form1.save()
            return redirect('/add')
    else:
        form1 = AddFarmerForm1
    return render(request, 'reason.html', {'form1': form1})

def add(request):
    return redirect('/success')



def success(request):
    form1=AddFarmerForm1(request.POST)
    if request.method == 'POST':
        form1 = ReasonForm1(request.POST, request.FILES)

        if form1.is_valid():
            form1.save()
            return redirect('/success1')
    else:
        form1 = ReasonForm1
    return render(request, 'reason.html', {'form1': form1})

def success1(request):
    return render(request,'welcome.html')
#delete
def deletefarmer(request):
    return render(request,'deleteform.html')

def deletesearch(request):
    id=request.POST['id']
    add_farmer2=Add_Farmer1.objects.filter(farmer_id=id)

    return render(request,'deleteshow.html',{'add_farmer2':add_farmer2})

def delete(request,id):
    add_farmer=Add_Farmer1.objects.get(id=id)
    add_farmer.delete()
    return render(request,'welcome.html')

#update

def adhar(request):
    return render(request,'adharform.html')

def searchupdate(request):
    id = request.POST['id']
    add_farmer2 = Add_Farmer1.objects.filter(farmer_id=id)

    return render(request, 'updateshow.html', {'add_farmer2': add_farmer2})

def edit(request,id):
    add_farmer=Add_Farmer1.objects.get(id=id)
    return render(request,'edit.html',{'add_farmer':add_farmer})

def update(request,id):
    add_farmer=Add_Farmer1.objects.get(id=id)
    form = AddFarmerForm1(request.POST, instance=add_farmer)
    form.save()
    return render(request,'updatemsg.html')

#reason farmer
def show2(request):
    reason=Reason1.objects.all
    return  render(request,'show2.html',{'reason':reason})

def deletereason(request,id):
    reason_farmer=Reason1.objects.get(id=id)
    reason_farmer.delete()
    return render(request,'delmsg.html')

def show(request):

    add_farmer=Add_Farmer1.objects.all
    return render(request,'show.html',{'add_farmer':add_farmer})

def showimage(request, id):

    photo=Reason1.objects.get(id=id)
    return render(request,'image.html',{'photo':photo})


#show farmer
def index(request):
    return render(request,'index-1.html')

def login(request):
    sid=request.POST['id']
    add_farmer2 = Add_Farmer1.objects.filter(farmer_id=sid)
    return render(request,'login.html',{'add_farmer2':add_farmer2})

#search box
def search2(request):
    given_adharno=request.POST['adharno']
    add_farmer2=Add_Farmer1.objects.filter(Adhar_no=given_adharno)
    return render(request, 'show1.html', {'add_farmer2': add_farmer2})

#login
def problem(request):
    if request.method == 'POST':
        form1 = ProblemForm1(request.POST, request.FILES)

        if form1.is_valid():
            form1.save()
            return redirect('/addproblem')
    else:
        form1 = ProblemForm1
    return render(request, 'forms2.html', {'form1': form1})

def addproblem(request):

    return render(request, 'welcome.html')

#showproblemfarmer

def showfarmerproblem(request):
    return  render(request,'showfarmerproblem.html')

def showfarmerproblem1(request):
    given_adharno=request.POST['adharno']
    problem=Problem1.objects.filter(Adhar_no=given_adharno)

    return render(request,'show3.html',{'problem':problem})

def deletefarmerproblem(request,id):
    problem=Problem1.objects.get(id=id)
    problem.delete()
    return render(request,'delmsg.html')

def abouthome(request):
    return render(request,'abouthome.html')

"""def problemform(request):
    #form=Problem1.objects.get(id=id)
    return render(request,'problemform.html')"""

def problemform(request,id):
    form=Problem1.objects.get(id=id)
    return render(request,'problemform.html',{'form':form})

def answer(request):
    search1=request.POST['problemname']
    #search2=request.POST['adhar_no']
    problem1=Reason1.objects.filter(resource_name=search1)
   # problem2=Reason1.objects.filter(address1=search2)

    return render(request,'problem_form.html',{'problem1':problem1})
# 16/09/2020
def book(request):
    form=BookFarmerform
    return render(request,'Bookform.html',{'form':form})
#19/09/2020
def savebooking(request):
    return redirect('successbooking')
    
def successbooking(request):
    form1=Bookfarmer.objects.all

    return render(request,'showbooking.html',{'form1':form1})






#def media(request):
 #   open('add_farmer/')"""





