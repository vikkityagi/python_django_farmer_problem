from django import forms
from .models import Reason1

class ReasonForm1(forms.ModelForm):
    class Meta:
        model=Reason1


        fields= ['farmer_name', 'Adhar_no', 'resource_name', 'resource_description', 'address1', 'zip_code','image']