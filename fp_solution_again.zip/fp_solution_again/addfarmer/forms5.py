# 16/09/2020
from django import forms
from .models import Bookfarmer
class BookFarmerform(forms.ModelForm):
    class Meta:
        model=Bookfarmer
        fields=['addhar_no','farmer_name','farmer_father_name','phone_number','Addhar_no','address1','zip_code','district','bookingdate']