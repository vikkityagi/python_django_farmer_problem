from django import forms
from .models import Problem1

class ProblemForm1(forms.ModelForm):
    class Meta:
        model=Problem1
        fields= ['farmer_name','farmer_father_name','phone_number','Adhar_no','address1','address2','zip_code','district','state']
