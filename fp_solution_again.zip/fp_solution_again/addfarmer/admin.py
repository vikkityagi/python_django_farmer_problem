from django.contrib import admin

# Register your models here.
from .models import Add_Farmer1

admin.site.register(Add_Farmer1)

from .models import Reason1

admin.site.register(Reason1)

from .models import Problem1

admin.site.register(Problem1)

# 16/09/2020
from .models import  Bookfarmer

admin.site.register(Bookfarmer)