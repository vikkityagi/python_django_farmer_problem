from django.db import models
#17/09/2020
import datetime
# Create your models here.
class Add_Farmer1(models.Model):

    farmer_id=models.CharField(max_length=10, unique=True)
    farmer_name=models.CharField(max_length=40)
    farmer_father_name=models.CharField(max_length=40)
    phone_number = models.CharField(max_length=12)
    Adhar_no=models.CharField(max_length=16, unique=True)

    address1 = models.CharField(max_length=102)
    address2 = models.CharField(max_length=102)
    zip_code = models.CharField(max_length=12)

    district = models.CharField(max_length=102)
    state = models.CharField(max_length=102)

    def __str__(self):
        return self.Adhar_no

class Reason1(models.Model):

    farmer_name = models.CharField(max_length=40)

    Adhar_no = models.CharField(max_length=16, unique=True)

    resource_name = models.CharField(max_length=100)

    resource_description = models.CharField(max_length=200)

    address1 = models.CharField(max_length=102)

    zip_code = models.CharField(max_length=12)

    image = models.FileField(upload_to='addfarmer/images')

    def __str__(self):
        return self.Adhar_no

# 16/09/2020
class Problem1(models.Model):
    farmer_name = models.CharField(max_length=40)
    farmer_father_name = models.CharField(max_length=40)
    phone_number = models.CharField(max_length=12, unique=True)
    Adhar_no = models.CharField(max_length=16, unique=True)

    address1 = models.CharField(max_length=102)

    address2 = models.CharField(max_length=102)

    zip_code = models.CharField(max_length=12)

    district = models.CharField(max_length=102)

    state = models.CharField(max_length=16)

    def __str__(self):
        return self.Adhar_no


class Bookfarmer(models.Model):
    addhar_no=models.CharField(max_length=15,unique=True,default="")
    farmer_name = models.CharField(max_length=40)
    farmer_father_name = models.CharField(max_length=40)
    phone_number = models.CharField(max_length=12, unique=True)
    Addhar_no = models.CharField(max_length=16, unique=True)

    address1 = models.CharField(max_length=102)



    zip_code = models.CharField(max_length=12)

    district = models.CharField(max_length=102)

    bookingdate=models.CharField(max_length=50,default=datetime.datetime.now())



    def __str__(self):
        return self.Addhar_no




